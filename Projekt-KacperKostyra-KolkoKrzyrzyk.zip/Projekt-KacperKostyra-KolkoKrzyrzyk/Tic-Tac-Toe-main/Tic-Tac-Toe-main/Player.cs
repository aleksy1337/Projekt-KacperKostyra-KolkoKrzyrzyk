﻿namespace TicTacToe
{
    public enum Player
    {
        None, X, O
    }
}
